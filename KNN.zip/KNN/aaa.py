# -*- codeing = utf-8 -*-
import knn

knn.run()